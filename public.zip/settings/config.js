global.creator = "@bukan_mastah_owner"
global.token = "7862614006:AAHwxgNB40Kdnklh_7ap3f5UiVx7CsjySeA"
global.chatid = "6684566252"
global.watermark = "©bukan mastah"
